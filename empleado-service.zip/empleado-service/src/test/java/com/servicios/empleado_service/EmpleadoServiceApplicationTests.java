package com.servicios.empleado_service;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EmpleadoServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
