package com.servicios.registro_service;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RegistroServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(RegistroServiceApplication.class, args);
	}

}
