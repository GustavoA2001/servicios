package com.servicios.notificaciones_service;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class NotificacionesServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
